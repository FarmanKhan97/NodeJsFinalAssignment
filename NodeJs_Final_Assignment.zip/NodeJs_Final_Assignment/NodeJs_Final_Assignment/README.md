# Nagarro_JS_Todo_Bands
Training assignment for Nagarro.

Steps:

Step 1. npm install
Step 2. npm start
