db = 'mongodb://localhost:27017/TodoDB';

module.exports = {
    mongoURI: db
};
